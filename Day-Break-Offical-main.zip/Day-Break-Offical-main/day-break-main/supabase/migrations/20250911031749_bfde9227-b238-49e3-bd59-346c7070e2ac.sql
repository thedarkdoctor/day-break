-- Disable email confirmation for easier development testing
-- This allows users to sign up without email verification
-- You can re-enable this later in production

-- Note: This setting is actually controlled in the Supabase dashboard
-- under Authentication > Settings > Email auth
-- But we can check current auth settings