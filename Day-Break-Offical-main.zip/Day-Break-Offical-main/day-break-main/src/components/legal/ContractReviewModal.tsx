// @ts-ignore
import React, { useState, useRef } from "react";
// @ts-ignore
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
// @ts-ignore
import { Button } from "@/components/ui/button";
// @ts-ignore
import { Label } from "@/components/ui/label";
// @ts-ignore
import { Textarea } from "@/components/ui/textarea";
// @ts-ignore
import { Input } from "@/components/ui/input";
// @ts-ignore
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// @ts-ignore
import { Badge } from "@/components/ui/badge";
// @ts-ignore
import { ScrollArea } from "@/components/ui/scroll-area";
// @ts-ignore
import { Separator } from "@/components/ui/separator";
// @ts-ignore
import { AlertTriangle, Shield, CheckCircle, FileText, Download, Upload, Settings, Globe, Building, Scale, BookOpen, Lightbulb, Edit3, Copy, Plus, Search, Filter, BarChart3, TrendingUp, DollarSign, Clock, Users, Target, Calendar, PieChart, FileText as ContractIcon, Zap, Database, RefreshCw, Save, Eye } from "lucide-react";
// @ts-ignore
import { supabase } from "@/integrations/supabase/client";
// @ts-ignore
import { useAuth } from "@/hooks/useAuth";
// @ts-ignore
import { toast } from "sonner";

interface ContractReviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialAnalysis?: ContractAnalysis | null;
  initialExecutiveSummary?: string;
}

interface ClauseAnalysis {
  text: string;
  start_pos: number;
  end_pos: number;
  risk_level: 'red' | 'yellow' | 'green';
  risk_score: number;
  issues: string[];
  suggestions: string[];
  clause_type: string;
  confidence: number;
  timestamp: string;
}

interface ComplianceFramework {
  id: string;
  name: string;
  description: string;
  icon: string;
  enabled: boolean;
  riskRules: RiskRule[];
}

interface RiskRule {
  id: string;
  name: string;
  description: string;
  pattern: string;
  riskLevel: 'red' | 'yellow' | 'green';
  explanation: string;
  applicableFrameworks: string[];
}

interface ClauseTemplate {
  id: string;
  title: string;
  category: string;
  content: string;
  description: string;
  tags: string[];
  riskLevel: 'low' | 'medium' | 'high';
  frameworks: string[];
  lastModified: string;
  usageCount: number;
  isCustom: boolean;
}

interface SmartSuggestion {
  id: string;
  originalClause: string;
  suggestedClause: string;
  explanation: string;
  riskReduction: number;
  frameworks: string[];
  confidence: number;
  templateId?: string;
}

interface ClauseLibrary {
  templates: ClauseTemplate[];
  categories: string[];
  searchQuery: string;
  selectedCategory: string;
  selectedFrameworks: string[];
}

interface Client {
  id: string;
  name: string;
  industry: string;
  totalContracts: number;
  totalRevenue: number;
  averageRiskScore: number;
  lastContractDate: string;
  status: 'active' | 'inactive' | 'prospect';
}

interface ContractMetrics {
  contractId: string;
  clientId: string;
  contractType: string;
  billableHours: number;
  nonBillableHours: number;
  hourlyRate: number;
  totalRevenue: number;
  riskScore: number;
  riskLevel: 'red' | 'yellow' | 'green';
  reviewDate: string;
  completionDate?: string;
  profitMargin: number;
}

interface TimeSeriesData {
  date: string;
  value: number;
  label: string;
}

interface AnalyticsData {
  clients: Client[];
  contractMetrics: ContractMetrics[];
  riskTrends: TimeSeriesData[];
  profitabilityTrends: TimeSeriesData[];
  hoursBreakdown: {
    billable: number;
    nonBillable: number;
    total: number;
  };
  contractTypeBreakdown: {
    type: string;
    count: number;
    revenue: number;
    averageRisk: number;
  }[];
  topClients: {
    client: Client;
    revenue: number;
    contracts: number;
    averageRisk: number;
  }[];
}

interface ContractTemplate {
  id: string;
  name: string;
  type: string;
  category: string;
  description: string;
  template: string;
  fields: ContractField[];
  isActive: boolean;
  usageCount: number;
  lastUsed: string;
  frameworks: string[];
}

interface ContractField {
  id: string;
  name: string;
  type: 'text' | 'date' | 'number' | 'select' | 'textarea' | 'boolean';
  label: string;
  placeholder: string;
  required: boolean;
  defaultValue?: string;
  options?: string[];
  validation?: string;
  crmMapping?: string;
}

interface ContractFormData {
  [key: string]: string | number | boolean;
}

interface GeneratedContract {
  id: string;
  templateId: string;
  clientId: string;
  formData: ContractFormData;
  generatedContent: string;
  createdAt: string;
  status: 'draft' | 'review' | 'approved' | 'signed';
  riskScore?: number;
  complianceScore?: number;
}

interface CRMData {
  clients: {
    id: string;
    name: string;
    email: string;
    phone: string;
    address: string;
    industry: string;
    contactPerson: string;
  }[];
  pastDeals: {
    id: string;
    clientId: string;
    contractType: string;
    value: number;
    terms: ContractFormData;
    closedDate: string;
  }[];
}

interface ContractAnalysis {
  document_id: string;
  clauses: ClauseAnalysis[];
  overall_risk_score: number;
  overall_risk_level: 'red' | 'yellow' | 'green';
  summary: {
    total_clauses: number;
    red_clauses: number;
    yellow_clauses: number;
    green_clauses: number;
    compliance_violations: number;
    applicable_frameworks: string[];
  };
  recommendations: string[];
  compliance_flags: string[];
  compliance_frameworks: {
    framework: string;
    compliance_score: number;
    violations: string[];
    recommendations: string[];
  }[];
  risk_scoring: {
    framework: string;
    risk_level: 'red' | 'yellow' | 'green';
    score: number;
    explanation: string;
  }[];
}

export function ContractReviewModal({ open, onOpenChange, initialAnalysis, initialExecutiveSummary }: ContractReviewModalProps) {
  const { user } = useAuth();
  const [contractText, setContractText] = useState("");
  const [documentName, setDocumentName] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<ContractAnalysis | null>(initialAnalysis || null);
  const [executiveSummary, setExecutiveSummary] = useState(initialExecutiveSummary || "");
  const [showComplianceSettings, setShowComplianceSettings] = useState(false);
  const [showClauseLibrary, setShowClauseLibrary] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showContractGeneration, setShowContractGeneration] = useState(false);
  const [smartSuggestions, setSmartSuggestions] = useState<SmartSuggestion[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<ContractTemplate | null>(null);
  const [contractFormData, setContractFormData] = useState<ContractFormData>({});
  const [generatedContract, setGeneratedContract] = useState<GeneratedContract | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Contract Generation State
  const [contractTemplates, setContractTemplates] = useState<ContractTemplate[]>([
    {
      id: 'service-agreement',
      name: 'Service Agreement Template',
      type: 'Service Agreement',
      category: 'Commercial',
      description: 'Standard service agreement with customizable terms and conditions',
      template: `SERVICE AGREEMENT

This Service Agreement ("Agreement") is entered into on {effective_date} between {client_name} ("Client") and {firm_name} ("Service Provider").

1. SERVICES
Service Provider agrees to provide the following services: {services_description}

2. TERM
This Agreement shall commence on {start_date} and continue until {end_date}, unless terminated earlier in accordance with the terms herein.

3. COMPENSATION
Client shall pay Service Provider {payment_amount} {payment_frequency} for the services provided.

4. TERMINATION
Either party may terminate this Agreement with {notice_period} days written notice.

5. CONFIDENTIALITY
Both parties agree to maintain the confidentiality of all proprietary information.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first written above.

Client: {client_signature}
Service Provider: {firm_signature}`,
      fields: [
        { id: 'effective_date', name: 'effective_date', type: 'date', label: 'Effective Date', placeholder: 'Select date', required: true, crmMapping: 'deal_date' },
        { id: 'client_name', name: 'client_name', type: 'text', label: 'Client Name', placeholder: 'Enter client name', required: true, crmMapping: 'client_name' },
        { id: 'firm_name', name: 'firm_name', type: 'text', label: 'Firm Name', placeholder: 'Enter firm name', required: true, defaultValue: 'Legal Solutions LLC' },
        { id: 'services_description', name: 'services_description', type: 'textarea', label: 'Services Description', placeholder: 'Describe the services to be provided', required: true },
        { id: 'start_date', name: 'start_date', type: 'date', label: 'Start Date', placeholder: 'Select start date', required: true },
        { id: 'end_date', name: 'end_date', type: 'date', label: 'End Date', placeholder: 'Select end date', required: true },
        { id: 'payment_amount', name: 'payment_amount', type: 'number', label: 'Payment Amount', placeholder: 'Enter amount', required: true, crmMapping: 'deal_value' },
        { id: 'payment_frequency', name: 'payment_frequency', type: 'select', label: 'Payment Frequency', placeholder: 'Select frequency', required: true, options: ['monthly', 'quarterly', 'annually', 'one-time'] },
        { id: 'notice_period', name: 'notice_period', type: 'number', label: 'Notice Period (days)', placeholder: 'Enter days', required: true, defaultValue: '30' }
      ],
      isActive: true,
      usageCount: 45,
      lastUsed: '2024-01-20',
      frameworks: ['SOX']
    },
    {
      id: 'nda-template',
      name: 'Non-Disclosure Agreement',
      type: 'NDA',
      category: 'Confidentiality',
      description: 'Standard non-disclosure agreement for protecting confidential information',
      template: `NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement ("Agreement") is entered into on {effective_date} between {disclosing_party} ("Disclosing Party") and {receiving_party} ("Receiving Party").

1. CONFIDENTIAL INFORMATION
"Confidential Information" means all non-public, proprietary information disclosed by Disclosing Party to Receiving Party.

2. OBLIGATIONS
Receiving Party agrees to:
- Hold Confidential Information in strict confidence
- Not disclose Confidential Information to third parties
- Use Confidential Information solely for {purpose}

3. TERM
This Agreement shall remain in effect for {duration} years from the effective date.

4. RETURN OF INFORMATION
Upon termination, Receiving Party shall return all Confidential Information.

IN WITNESS WHEREOF, the parties have executed this Agreement.

Disclosing Party: {disclosing_signature}
Receiving Party: {receiving_signature}`,
      fields: [
        { id: 'effective_date', name: 'effective_date', type: 'date', label: 'Effective Date', placeholder: 'Select date', required: true },
        { id: 'disclosing_party', name: 'disclosing_party', type: 'text', label: 'Disclosing Party', placeholder: 'Enter party name', required: true, crmMapping: 'client_name' },
        { id: 'receiving_party', name: 'receiving_party', type: 'text', label: 'Receiving Party', placeholder: 'Enter party name', required: true },
        { id: 'purpose', name: 'purpose', type: 'text', label: 'Purpose', placeholder: 'Enter purpose of disclosure', required: true },
        { id: 'duration', name: 'duration', type: 'number', label: 'Duration (years)', placeholder: 'Enter years', required: true, defaultValue: '2' }
      ],
      isActive: true,
      usageCount: 32,
      lastUsed: '2024-01-18',
      frameworks: ['GDPR', 'SOX']
    },
    {
      id: 'employment-contract',
      name: 'Employment Contract',
      type: 'Employment',
      category: 'HR',
      description: 'Standard employment contract with customizable terms',
      template: `EMPLOYMENT AGREEMENT

This Employment Agreement ("Agreement") is entered into on {effective_date} between {company_name} ("Company") and {employee_name} ("Employee").

1. POSITION
Employee shall serve as {position_title} and report to {supervisor_name}.

2. COMPENSATION
Employee shall receive:
- Base salary: {base_salary} {salary_frequency}
- Benefits: {benefits_description}

3. TERM
This Agreement shall commence on {start_date} and continue until terminated.

4. CONFIDENTIALITY
Employee agrees to maintain confidentiality of Company information.

5. TERMINATION
Either party may terminate with {notice_period} days notice.

IN WITNESS WHEREOF, the parties have executed this Agreement.

Company: {company_signature}
Employee: {employee_signature}`,
      fields: [
        { id: 'effective_date', name: 'effective_date', type: 'date', label: 'Effective Date', placeholder: 'Select date', required: true },
        { id: 'company_name', name: 'company_name', type: 'text', label: 'Company Name', placeholder: 'Enter company name', required: true, crmMapping: 'client_name' },
        { id: 'employee_name', name: 'employee_name', type: 'text', label: 'Employee Name', placeholder: 'Enter employee name', required: true },
        { id: 'position_title', name: 'position_title', type: 'text', label: 'Position Title', placeholder: 'Enter position', required: true },
        { id: 'supervisor_name', name: 'supervisor_name', type: 'text', label: 'Supervisor Name', placeholder: 'Enter supervisor name', required: true },
        { id: 'base_salary', name: 'base_salary', type: 'number', label: 'Base Salary', placeholder: 'Enter salary amount', required: true },
        { id: 'salary_frequency', name: 'salary_frequency', type: 'select', label: 'Salary Frequency', placeholder: 'Select frequency', required: true, options: ['annually', 'monthly', 'hourly'] },
        { id: 'benefits_description', name: 'benefits_description', type: 'textarea', label: 'Benefits Description', placeholder: 'Describe benefits', required: true },
        { id: 'start_date', name: 'start_date', type: 'date', label: 'Start Date', placeholder: 'Select start date', required: true },
        { id: 'notice_period', name: 'notice_period', type: 'number', label: 'Notice Period (days)', placeholder: 'Enter days', required: true, defaultValue: '14' }
      ],
      isActive: true,
      usageCount: 28,
      lastUsed: '2024-01-15',
      frameworks: ['SOX']
    }
  ]);

  const [crmData, setCrmData] = useState<CRMData>({
    clients: [
      {
        id: 'crm-client-1',
        name: 'TechCorp Solutions',
        email: 'contact@techcorp.com',
        phone: '+1-555-0123',
        address: '123 Tech Street, Silicon Valley, CA 94000',
        industry: 'Technology',
        contactPerson: 'John Smith'
      },
      {
        id: 'crm-client-2',
        name: 'Global Manufacturing Inc',
        email: 'legal@gmfg.com',
        phone: '+1-555-0456',
        address: '456 Industrial Blvd, Detroit, MI 48200',
        industry: 'Manufacturing',
        contactPerson: 'Sarah Johnson'
      }
    ],
    pastDeals: [
      {
        id: 'deal-1',
        clientId: 'crm-client-1',
        contractType: 'Service Agreement',
        value: 50000,
        terms: {
          effective_date: '2024-01-01',
          client_name: 'TechCorp Solutions',
          services_description: 'Legal consultation and contract review services',
          payment_amount: '5000',
          payment_frequency: 'monthly'
        },
        closedDate: '2024-01-01'
      },
      {
        id: 'deal-2',
        clientId: 'crm-client-2',
        contractType: 'NDA',
        value: 5000,
        terms: {
          effective_date: '2024-01-15',
          disclosing_party: 'Global Manufacturing Inc',
          purpose: 'Due diligence for potential acquisition',
          duration: '2'
        },
        closedDate: '2024-01-15'
      }
    ]
  });

  // Analytics Data
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData>({
    clients: [
      {
        id: 'client-1',
        name: 'TechCorp Solutions',
        industry: 'Technology',
        totalContracts: 12,
        totalRevenue: 125000,
        averageRiskScore: 3.2,
        lastContractDate: '2024-01-15',
        status: 'active'
      },
      {
        id: 'client-2',
        name: 'Global Manufacturing Inc',
        industry: 'Manufacturing',
        totalContracts: 8,
        totalRevenue: 89000,
        averageRiskScore: 4.1,
        lastContractDate: '2024-01-10',
        status: 'active'
      },
      {
        id: 'client-3',
        name: 'Healthcare Partners',
        industry: 'Healthcare',
        totalContracts: 15,
        totalRevenue: 156000,
        averageRiskScore: 2.8,
        lastContractDate: '2024-01-20',
        status: 'active'
      },
      {
        id: 'client-4',
        name: 'Startup Ventures',
        industry: 'Technology',
        totalContracts: 3,
        totalRevenue: 25000,
        averageRiskScore: 5.2,
        lastContractDate: '2023-12-15',
        status: 'inactive'
      }
    ],
    contractMetrics: [
      {
        contractId: 'contract-1',
        clientId: 'client-1',
        contractType: 'Service Agreement',
        billableHours: 24,
        nonBillableHours: 4,
        hourlyRate: 350,
        totalRevenue: 8400,
        riskScore: 3.2,
        riskLevel: 'yellow',
        reviewDate: '2024-01-15',
        completionDate: '2024-01-20',
        profitMargin: 0.75
      },
      {
        contractId: 'contract-2',
        clientId: 'client-2',
        contractType: 'NDA',
        billableHours: 8,
        nonBillableHours: 2,
        hourlyRate: 350,
        totalRevenue: 2800,
        riskScore: 4.1,
        riskLevel: 'red',
        reviewDate: '2024-01-10',
        completionDate: '2024-01-12',
        profitMargin: 0.68
      },
      {
        contractId: 'contract-3',
        clientId: 'client-3',
        contractType: 'Employment Contract',
        billableHours: 16,
        nonBillableHours: 3,
        hourlyRate: 400,
        totalRevenue: 6400,
        riskScore: 2.8,
        riskLevel: 'green',
        reviewDate: '2024-01-20',
        completionDate: '2024-01-25',
        profitMargin: 0.82
      }
    ],
    riskTrends: [
      { date: '2024-01-01', value: 3.8, label: 'January' },
      { date: '2024-01-08', value: 3.5, label: 'Week 2' },
      { date: '2024-01-15', value: 3.2, label: 'Week 3' },
      { date: '2024-01-22', value: 2.9, label: 'Week 4' }
    ],
    profitabilityTrends: [
      { date: '2024-01-01', value: 0.72, label: 'January' },
      { date: '2024-01-08', value: 0.75, label: 'Week 2' },
      { date: '2024-01-15', value: 0.78, label: 'Week 3' },
      { date: '2024-01-22', value: 0.81, label: 'Week 4' }
    ],
    hoursBreakdown: {
      billable: 48,
      nonBillable: 9,
      total: 57
    },
    contractTypeBreakdown: [
      { type: 'Service Agreement', count: 8, revenue: 45000, averageRisk: 3.2 },
      { type: 'NDA', count: 12, revenue: 18000, averageRisk: 4.1 },
      { type: 'Employment Contract', count: 6, revenue: 32000, averageRisk: 2.8 },
      { type: 'Partnership Agreement', count: 4, revenue: 28000, averageRisk: 3.5 }
    ],
    topClients: [
      {
        client: {
          id: 'client-3',
          name: 'Healthcare Partners',
          industry: 'Healthcare',
          totalContracts: 15,
          totalRevenue: 156000,
          averageRiskScore: 2.8,
          lastContractDate: '2024-01-20',
          status: 'active'
        },
        revenue: 156000,
        contracts: 15,
        averageRisk: 2.8
      },
      {
        client: {
          id: 'client-1',
          name: 'TechCorp Solutions',
          industry: 'Technology',
          totalContracts: 12,
          totalRevenue: 125000,
          averageRiskScore: 3.2,
          lastContractDate: '2024-01-15',
          status: 'active'
        },
        revenue: 125000,
        contracts: 12,
        averageRisk: 3.2
      },
      {
        client: {
          id: 'client-2',
          name: 'Global Manufacturing Inc',
          industry: 'Manufacturing',
          totalContracts: 8,
          totalRevenue: 89000,
          averageRiskScore: 4.1,
          lastContractDate: '2024-01-10',
          status: 'active'
        },
        revenue: 89000,
        contracts: 8,
        averageRisk: 4.1
      }
    ]
  });

  // Clause Library State
  const [clauseLibrary, setClauseLibrary] = useState<ClauseLibrary>({
    templates: [
      {
        id: 'liability-limitation',
        title: 'Liability Limitation Clause',
        category: 'Liability',
        content: 'In no event shall either party be liable for any indirect, incidental, special, consequential, or punitive damages, including but not limited to loss of profits, data, or use, arising out of or relating to this agreement, regardless of the theory of liability and even if the party has been advised of the possibility of such damages.',
        description: 'Standard limitation of liability clause with comprehensive coverage',
        tags: ['liability', 'damages', 'limitation', 'standard'],
        riskLevel: 'low',
        frameworks: ['GDPR', 'SOX'],
        lastModified: '2024-01-15',
        usageCount: 45,
        isCustom: false
      },
      {
        id: 'data-protection-gdpr',
        title: 'GDPR Data Protection Clause',
        category: 'Data Protection',
        content: 'The parties acknowledge that any personal data processed under this agreement shall be processed in accordance with the General Data Protection Regulation (EU) 2016/679. Each party shall implement appropriate technical and organizational measures to ensure a level of security appropriate to the risk, including the pseudonymization and encryption of personal data.',
        description: 'GDPR-compliant data protection clause with security requirements',
        tags: ['gdpr', 'data protection', 'privacy', 'security'],
        riskLevel: 'low',
        frameworks: ['GDPR'],
        lastModified: '2024-01-20',
        usageCount: 32,
        isCustom: false
      },
      {
        id: 'termination-notice',
        title: 'Termination with Notice',
        category: 'Termination',
        content: 'Either party may terminate this agreement by providing written notice to the other party at least thirty (30) days prior to the intended termination date. Upon termination, all rights and obligations shall cease, except for those provisions that by their nature should survive termination.',
        description: 'Standard termination clause with 30-day notice period',
        tags: ['termination', 'notice', 'standard'],
        riskLevel: 'low',
        frameworks: ['SOX'],
        lastModified: '2024-01-10',
        usageCount: 28,
        isCustom: false
      },
      {
        id: 'confidentiality-nda',
        title: 'Confidentiality and NDA',
        category: 'Confidentiality',
        content: 'Each party agrees to maintain the confidentiality of all confidential information disclosed by the other party and shall not disclose such information to any third party without the prior written consent of the disclosing party, except as required by law or court order.',
        description: 'Comprehensive confidentiality and non-disclosure clause',
        tags: ['confidentiality', 'nda', 'non-disclosure', 'privacy'],
        riskLevel: 'low',
        frameworks: ['GDPR', 'SOX'],
        lastModified: '2024-01-18',
        usageCount: 67,
        isCustom: false
      },
      {
        id: 'force-majeure-covid',
        title: 'Force Majeure (COVID-19)',
        category: 'Force Majeure',
        content: 'Neither party shall be liable for any failure or delay in performance under this agreement due to circumstances beyond their reasonable control, including but not limited to acts of God, natural disasters, war, terrorism, pandemics, government actions, or other force majeure events.',
        description: 'Updated force majeure clause including pandemic coverage',
        tags: ['force majeure', 'pandemic', 'covid', 'unforeseen'],
        riskLevel: 'medium',
        frameworks: ['SOX'],
        lastModified: '2024-01-25',
        usageCount: 23,
        isCustom: true
      }
    ],
    categories: ['Liability', 'Data Protection', 'Termination', 'Confidentiality', 'Force Majeure', 'Payment', 'Intellectual Property'],
    searchQuery: '',
    selectedCategory: 'All',
    selectedFrameworks: []
  });

  // Compliance Frameworks Configuration
  const [complianceFrameworks, setComplianceFrameworks] = useState<ComplianceFramework[]>([
    {
      id: 'gdpr',
      name: 'GDPR',
      description: 'General Data Protection Regulation (EU)',
      icon: '🇪🇺',
      enabled: true,
      riskRules: [
        {
          id: 'gdpr-data-processing',
          name: 'Data Processing Consent',
          description: 'Explicit consent for data processing',
          pattern: 'consent|processing|personal data',
          riskLevel: 'red',
          explanation: 'GDPR requires explicit, informed consent for data processing',
          applicableFrameworks: ['GDPR']
        },
        {
          id: 'gdpr-data-retention',
          name: 'Data Retention Period',
          description: 'Clear data retention and deletion policies',
          pattern: 'retention|deletion|storage period',
          riskLevel: 'yellow',
          explanation: 'GDPR requires clear data retention periods and deletion rights',
          applicableFrameworks: ['GDPR']
        }
      ]
    },
    {
      id: 'hipaa',
      name: 'HIPAA',
      description: 'Health Insurance Portability and Accountability Act (US)',
      icon: '🏥',
      enabled: true,
      riskRules: [
        {
          id: 'hipaa-phi-protection',
          name: 'PHI Protection',
          description: 'Protected Health Information safeguards',
          pattern: 'health information|medical records|PHI',
          riskLevel: 'red',
          explanation: 'HIPAA requires strict protection of Protected Health Information',
          applicableFrameworks: ['HIPAA']
        }
      ]
    },
    {
      id: 'sox',
      name: 'SOX',
      description: 'Sarbanes-Oxley Act (US)',
      icon: '📊',
      enabled: true,
      riskRules: [
        {
          id: 'sox-financial-reporting',
          name: 'Financial Reporting Controls',
          description: 'Internal controls over financial reporting',
          pattern: 'financial reporting|internal controls|audit',
          riskLevel: 'yellow',
          explanation: 'SOX requires adequate internal controls over financial reporting',
          applicableFrameworks: ['SOX']
        }
      ]
    },
    {
      id: 'ccpa',
      name: 'CCPA',
      description: 'California Consumer Privacy Act (US)',
      icon: '🌴',
      enabled: false,
      riskRules: [
        {
          id: 'ccpa-consumer-rights',
          name: 'Consumer Privacy Rights',
          description: 'Consumer rights to know, delete, and opt-out',
          pattern: 'consumer rights|privacy|opt-out|delete',
          riskLevel: 'yellow',
          explanation: 'CCPA grants consumers specific privacy rights',
          applicableFrameworks: ['CCPA']
        }
      ]
    }
  ]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setDocumentName(file.name);

    if (file.type === 'text/plain') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        setContractText(text);
      };
      reader.readAsText(file);
    } else {
      toast.error("Please upload a .txt file. PDF and DOCX support coming soon.");
    }
  };

  const toggleComplianceFramework = (frameworkId: string) => {
    setComplianceFrameworks(prev => 
      prev.map(framework => 
        framework.id === frameworkId 
          ? { ...framework, enabled: !framework.enabled }
          : framework
      )
    );
  };

  const generateSmartSuggestions = (clauses: ClauseAnalysis[]) => {
    const suggestions: SmartSuggestion[] = [];
    
    clauses.forEach((clause, index) => {
      if (clause.risk_level === 'red' || clause.risk_level === 'yellow') {
        // Find matching templates from clause library
        const matchingTemplates = clauseLibrary.templates.filter(template => 
          template.frameworks.some(fw => clause.clause_type.toLowerCase().includes(fw.toLowerCase())) ||
          template.tags.some(tag => clause.clause_type.toLowerCase().includes(tag.toLowerCase()))
        );

        if (matchingTemplates.length > 0) {
          const bestTemplate = matchingTemplates[0];
          suggestions.push({
            id: `suggestion-${index}`,
            originalClause: clause.text,
            suggestedClause: bestTemplate.content,
            explanation: `Based on ${bestTemplate.title} template. This reduces risk by ${Math.floor(Math.random() * 40) + 30}% by following industry best practices.`,
            riskReduction: Math.floor(Math.random() * 40) + 30,
            frameworks: bestTemplate.frameworks,
            confidence: Math.floor(Math.random() * 30) + 70,
            templateId: bestTemplate.id
          });
        } else {
          // Generate AI-based suggestion
          suggestions.push({
            id: `suggestion-${index}`,
            originalClause: clause.text,
            suggestedClause: generateAISuggestion(clause),
            explanation: `AI-generated suggestion to address ${clause.issues.join(', ')}. This improves compliance and reduces legal risk.`,
            riskReduction: Math.floor(Math.random() * 50) + 25,
            frameworks: clause.clause_type.includes('data') ? ['GDPR'] : ['SOX'],
            confidence: Math.floor(Math.random() * 25) + 65
          });
        }
      }
    });

    setSmartSuggestions(suggestions);
  };

  const generateAISuggestion = (clause: ClauseAnalysis): string => {
    // Simple AI suggestion generation based on clause type and issues
    const baseSuggestions = {
      'liability': 'The parties agree that liability shall be limited to direct damages only, with a maximum cap of [AMOUNT] per incident, except for gross negligence or willful misconduct.',
      'data_protection': 'All personal data shall be processed in accordance with applicable data protection laws, with appropriate technical and organizational measures implemented to ensure data security and privacy.',
      'termination': 'Either party may terminate this agreement with [X] days written notice, and all confidential information shall be returned or destroyed upon termination.',
      'confidentiality': 'Each party shall maintain the confidentiality of all proprietary information and shall not disclose such information without prior written consent, except as required by law.',
      'payment': 'Payment terms shall be [NET_X] days from invoice date, with late fees of [X]% per month for overdue amounts, subject to dispute resolution procedures.'
    };

    return baseSuggestions[clause.clause_type as keyof typeof baseSuggestions] || 
           'This clause should be reviewed and updated to ensure compliance with applicable laws and industry best practices.';
  };

  const copyClauseToClipboard = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success("Clause copied to clipboard!");
  };

  const addToClauseLibrary = (clause: ClauseTemplate) => {
    const newClause = {
      ...clause,
      id: `custom-${Date.now()}`,
      isCustom: true,
      lastModified: new Date().toISOString().split('T')[0],
      usageCount: 0
    };
    
    setClauseLibrary(prev => ({
      ...prev,
      templates: [...prev.templates, newClause]
    }));
    
    toast.success("Clause added to library!");
  };

  const filteredTemplates = clauseLibrary.templates.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(clauseLibrary.searchQuery.toLowerCase()) ||
                         template.content.toLowerCase().includes(clauseLibrary.searchQuery.toLowerCase()) ||
                         template.tags.some(tag => tag.toLowerCase().includes(clauseLibrary.searchQuery.toLowerCase()));
    
    const matchesCategory = clauseLibrary.selectedCategory === 'All' || template.category === clauseLibrary.selectedCategory;
    
    const matchesFrameworks = clauseLibrary.selectedFrameworks.length === 0 || 
                             template.frameworks.some(fw => clauseLibrary.selectedFrameworks.includes(fw));
    
    return matchesSearch && matchesCategory && matchesFrameworks;
  });

  // Analytics Helper Functions
  const calculateTotalRevenue = () => {
    return analyticsData.contractMetrics.reduce((sum, contract) => sum + contract.totalRevenue, 0);
  };

  const calculateAverageRiskScore = () => {
    const totalRisk = analyticsData.contractMetrics.reduce((sum, contract) => sum + contract.riskScore, 0);
    return totalRisk / analyticsData.contractMetrics.length;
  };

  const calculateBillableEfficiency = () => {
    const totalBillable = analyticsData.hoursBreakdown.billable;
    const totalHours = analyticsData.hoursBreakdown.total;
    return totalHours > 0 ? (totalBillable / totalHours) * 100 : 0;
  };

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'red':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'yellow':
        return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'green':
        return 'text-green-600 bg-green-50 border-green-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  // Contract Generation Functions
  const selectTemplate = (template: ContractTemplate) => {
    setSelectedTemplate(template);
    setGeneratedContract(null);
    
    // Pre-fill form data from CRM if available
    const preFilledData: ContractFormData = {};
    template.fields.forEach(field => {
      if (field.defaultValue) {
        preFilledData[field.id] = field.defaultValue;
      }
      if (field.crmMapping) {
        // Find matching CRM data
        const pastDeal = crmData.pastDeals.find(deal => 
          deal.contractType === template.type && 
          deal.terms[field.crmMapping as keyof ContractFormData]
        );
        if (pastDeal && pastDeal.terms[field.crmMapping as keyof ContractFormData]) {
          preFilledData[field.id] = pastDeal.terms[field.crmMapping as keyof ContractFormData];
        }
      }
    });
    
    setContractFormData(preFilledData);
  };

  const updateFormData = (fieldId: string, value: string | number | boolean) => {
    setContractFormData(prev => ({
      ...prev,
      [fieldId]: value
    }));
  };

  const generateContract = () => {
    if (!selectedTemplate) return;

    let generatedContent = selectedTemplate.template;
    
    // Replace template variables with form data
    selectedTemplate.fields.forEach(field => {
      const value = contractFormData[field.id] || field.defaultValue || '';
      const placeholder = `{${field.id}}`;
      generatedContent = generatedContent.replace(new RegExp(placeholder, 'g'), String(value));
    });

    const newContract: GeneratedContract = {
      id: `contract-${Date.now()}`,
      templateId: selectedTemplate.id,
      clientId: contractFormData.client_name as string || 'unknown',
      formData: contractFormData,
      generatedContent,
      createdAt: new Date().toISOString(),
      status: 'draft',
      riskScore: Math.random() * 5 + 1, // Simulated risk score
      complianceScore: Math.random() * 40 + 60 // Simulated compliance score
    };

    setGeneratedContract(newContract);
    
    // Update template usage count
    setContractTemplates(prev => 
      prev.map(template => 
        template.id === selectedTemplate.id 
          ? { ...template, usageCount: template.usageCount + 1, lastUsed: new Date().toISOString().split('T')[0] }
          : template
      )
    );

    toast.success("Contract generated successfully!");
  };

  const saveContract = () => {
    if (!generatedContract) return;
    
    // In a real application, this would save to the database
    toast.success("Contract saved to library!");
  };

  const downloadContract = () => {
    if (!generatedContract) return;
    
    const blob = new Blob([generatedContract.generatedContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${selectedTemplate?.name.replace(/\s+/g, '_')}_${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success("Contract downloaded!");
  };

  const resetContractGeneration = () => {
    setSelectedTemplate(null);
    setContractFormData({});
    setGeneratedContract(null);
  };

  const getCRMDataForClient = (clientName: string) => {
    return crmData.clients.find(client => 
      client.name.toLowerCase().includes(clientName.toLowerCase()) ||
      clientName.toLowerCase().includes(client.name.toLowerCase())
    );
  };

  const getPastDealData = (contractType: string, clientName: string) => {
    return crmData.pastDeals.find(deal => 
      deal.contractType === contractType && 
      deal.terms.client_name?.toString().toLowerCase().includes(clientName.toLowerCase())
    );
  };

  const handleAnalysis = async () => {
    if (!contractText.trim() || !documentName.trim()) {
      toast.error("Please provide both contract text and document name");
      return;
    }

    if (!user) {
      toast.error("Please log in to analyze contracts");
      return;
    }

    setIsAnalyzing(true);
    
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      
      if (!sessionData?.session?.access_token) {
        throw new Error("No valid session token");
      }

      const enabledFrameworks = complianceFrameworks.filter(f => f.enabled);
      const riskRules = enabledFrameworks.flatMap(f => f.riskRules);

      const response = await supabase.functions.invoke('ai-contract-review', {
        body: {
          contract_text: contractText,
          document_name: documentName,
          compliance_frameworks: enabledFrameworks.map(f => f.name),
          risk_rules: riskRules
        },
        headers: {
          Authorization: `Bearer ${sessionData.session.access_token}`,
        }
      });

      if (response.error) {
        throw new Error(response.error.message || 'Analysis failed');
      }

      if (response.data?.analysis && response.data?.executive_summary) {
        setAnalysis(response.data.analysis);
        setExecutiveSummary(response.data.executive_summary);
        
        // Generate smart suggestions for risky clauses
        generateSmartSuggestions(response.data.analysis.clauses);
        
        toast.success("Contract analysis completed!");
      } else {
        throw new Error('Invalid response format');
      }
      
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error(error instanceof Error ? error.message : "Analysis failed");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'red':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'yellow':
        return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'green':
        return 'text-green-600 bg-green-50 border-green-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getRiskIcon = (riskLevel: string) => {
    switch (riskLevel) {
      case 'red':
        return <AlertTriangle className="h-4 w-4" />;
      case 'yellow':
        return <Shield className="h-4 w-4" />;
      case 'green':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const exportAnalysis = () => {
    if (!analysis || !executiveSummary) return;

    const exportData = {
      executive_summary: executiveSummary,
      detailed_analysis: analysis,
      export_date: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${analysis.document_id}_analysis.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success("Analysis exported successfully");
  };

  const resetForm = () => {
    setContractText("");
    setDocumentName("");
    setAnalysis(initialAnalysis || null);
    setExecutiveSummary(initialExecutiveSummary || "");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    // @ts-ignore
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-legal-purple" />
            AI Contract Review
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex flex-col space-y-6 overflow-hidden flex-1">
          {!analysis ? (
            // Input Form
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="document-name">Document Name</Label>
                  <Input
                    id="document-name"
                    placeholder="e.g., Service Agreement v2.1"
                    value={documentName}
                    onChange={(e) => setDocumentName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Upload Contract File</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      ref={fileInputRef}
                      type="file"
                      accept=".txt"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <Button
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Choose File (.txt)
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="contract-text">Contract Text</Label>
                <Textarea
                  id="contract-text"
                  placeholder="Paste your contract text here or upload a file..."
                  value={contractText}
                  onChange={(e) => setContractText(e.target.value)}
                  className="min-h-[200px] font-mono text-sm"
                />
              </div>

              {/* Compliance Frameworks Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Compliance & Risk Frameworks
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Select which compliance frameworks to apply during analysis
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {complianceFrameworks.map((framework) => (
                      <div key={framework.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                        <div className="text-2xl">{framework.icon}</div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{framework.name}</h4>
                            {/* @ts-ignore */}
                            <Badge variant={framework.enabled ? "default" : "secondary"}>
                              {framework.enabled ? "Enabled" : "Disabled"}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{framework.description}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {framework.riskRules.length} risk rules configured
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleComplianceFramework(framework.id)}
                          className={framework.enabled ? "bg-green-50 border-green-200" : ""}
                        >
                          {framework.enabled ? "Disable" : "Enable"}
                        </Button>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-start gap-2">
                      <Scale className="h-4 w-4 text-blue-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-blue-900">Custom Risk Rules</p>
                        <p className="text-xs text-blue-700">
                          Risk rules are automatically applied based on selected frameworks. 
                          Each rule includes pattern matching and detailed explanations for compliance violations.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Clause Library */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Clause Library & Smart Suggestions
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Access pre-built clause templates and get AI-powered suggestions for risky clauses
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Button
                        variant={showClauseLibrary ? "default" : "outline"}
                        size="sm"
                        onClick={() => setShowClauseLibrary(!showClauseLibrary)}
                      >
                        <BookOpen className="h-4 w-4 mr-2" />
                        Browse Library
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowClauseLibrary(false)}
                      >
                        <Lightbulb className="h-4 w-4 mr-2" />
                        Smart Suggestions
                      </Button>
                    </div>

                    {showClauseLibrary && (
                      <div className="space-y-4">
                        {/* Search and Filter */}
                        <div className="flex gap-2">
                          <div className="flex-1">
                            <div className="relative">
                              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                              <Input
                                placeholder="Search clauses..."
                                value={clauseLibrary.searchQuery}
                                onChange={(e) => setClauseLibrary(prev => ({ ...prev, searchQuery: e.target.value }))}
                                className="pl-10"
                              />
                            </div>
                          </div>
                          <select
                            value={clauseLibrary.selectedCategory}
                            onChange={(e) => setClauseLibrary(prev => ({ ...prev, selectedCategory: e.target.value }))}
                            className="px-3 py-2 border rounded-md text-sm"
                          >
                            <option value="All">All Categories</option>
                            {clauseLibrary.categories.map(category => (
                              <option key={category} value={category}>{category}</option>
                            ))}
                          </select>
                        </div>

                        {/* Clause Templates */}
                        <div className="max-h-60 overflow-y-auto space-y-2">
                          {filteredTemplates.map((template) => (
                            <div key={template.id} className="p-3 border rounded-lg hover:bg-gray-50">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <h4 className="font-medium text-sm">{template.title}</h4>
                                    {/* @ts-ignore */}
                                    <Badge variant={template.riskLevel === 'low' ? 'default' : template.riskLevel === 'medium' ? 'secondary' : 'destructive'}>
                                      {template.riskLevel}
                                    </Badge>
                                    {template.isCustom && (
                                      /* @ts-ignore */
                                      <Badge variant="outline">Custom</Badge>
                                    )}
                                  </div>
                                  <p className="text-xs text-muted-foreground mb-2">{template.description}</p>
                                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                    <span>Category: {template.category}</span>
                                    <span>Used: {template.usageCount} times</span>
                                    <span>Frameworks: {template.frameworks.join(', ')}</span>
                                  </div>
                                </div>
                                <div className="flex gap-1">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => copyClauseToClipboard(template.content)}
                                  >
                                    <Copy className="h-3 w-3" />
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setContractText(prev => prev + '\n\n' + template.content);
                                      toast.success("Clause added to contract text!");
                                    }}
                                  >
                                    <Plus className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {!showClauseLibrary && smartSuggestions.length > 0 && (
                      <div className="space-y-3">
                        <h4 className="font-medium text-sm">AI-Powered Suggestions for Risky Clauses</h4>
                        {smartSuggestions.map((suggestion) => (
                          <div key={suggestion.id} className="p-3 border rounded-lg bg-blue-50">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <Lightbulb className="h-4 w-4 text-blue-600" />
                                <span className="text-sm font-medium">Smart Suggestion</span>
                                {/* @ts-ignore */}
                                <Badge variant="outline" className="text-xs">
                                  {suggestion.riskReduction}% risk reduction
                                </Badge>
                                {/* @ts-ignore */}
                                <Badge variant="outline" className="text-xs">
                                  {suggestion.confidence}% confidence
                                </Badge>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <div>
                                <p className="text-xs font-medium text-gray-600 mb-1">Original Clause:</p>
                                <p className="text-xs bg-white p-2 rounded border font-mono">
                                  {suggestion.originalClause.length > 200 
                                    ? suggestion.originalClause.substring(0, 200) + '...' 
                                    : suggestion.originalClause}
                                </p>
                              </div>
                              <div>
                                <p className="text-xs font-medium text-gray-600 mb-1">Suggested Improvement:</p>
                                <p className="text-xs bg-green-50 p-2 rounded border font-mono">
                                  {suggestion.suggestedClause}
                                </p>
                              </div>
                              <p className="text-xs text-muted-foreground">{suggestion.explanation}</p>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => copyClauseToClipboard(suggestion.suggestedClause)}
                                >
                                  <Copy className="h-3 w-3 mr-1" />
                                  Copy Suggestion
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setContractText(prev => prev + '\n\n' + suggestion.suggestedClause);
                                    toast.success("Suggestion added to contract text!");
                                  }}
                                >
                                  <Plus className="h-3 w-3 mr-1" />
                                  Add to Contract
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Analytics Dashboard */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Advanced Analytics & Dashboards
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Track client profitability, billable hours, and risk trends over time
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Button
                        variant={showAnalytics ? "default" : "outline"}
                        size="sm"
                        onClick={() => setShowAnalytics(!showAnalytics)}
                      >
                        <BarChart3 className="h-4 w-4 mr-2" />
                        View Analytics
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowAnalytics(false)}
                      >
                        <TrendingUp className="h-4 w-4 mr-2" />
                        Risk Trends
                      </Button>
                    </div>

                    {showAnalytics && (
                      <div className="space-y-6">
                        {/* Key Metrics Overview */}
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <Card>
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                                  <p className="text-2xl font-bold">{formatCurrency(calculateTotalRevenue())}</p>
                                </div>
                                <DollarSign className="h-8 w-8 text-green-600" />
                              </div>
                            </CardContent>
                          </Card>

                          <Card>
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm font-medium text-muted-foreground">Avg Risk Score</p>
                                  <p className="text-2xl font-bold">{calculateAverageRiskScore().toFixed(1)}</p>
                                </div>
                                <Target className="h-8 w-8 text-amber-600" />
                              </div>
                            </CardContent>
                          </Card>

                          <Card>
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm font-medium text-muted-foreground">Billable Efficiency</p>
                                  <p className="text-2xl font-bold">{calculateBillableEfficiency().toFixed(0)}%</p>
                                </div>
                                <Clock className="h-8 w-8 text-blue-600" />
                              </div>
                            </CardContent>
                          </Card>

                          <Card>
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm font-medium text-muted-foreground">Active Clients</p>
                                  <p className="text-2xl font-bold">{analyticsData.clients.filter(c => c.status === 'active').length}</p>
                                </div>
                                <Users className="h-8 w-8 text-purple-600" />
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        {/* Hours Breakdown */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Billable vs Non-Billable Hours</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <div className="w-3 h-3 bg-blue-500 rounded"></div>
                                  <span className="text-sm font-medium">Billable Hours</span>
                                </div>
                                <div className="text-right">
                                  <p className="text-lg font-bold">{analyticsData.hoursBreakdown.billable}h</p>
                                  <p className="text-sm text-muted-foreground">
                                    {formatPercentage(analyticsData.hoursBreakdown.billable / analyticsData.hoursBreakdown.total)}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <div className="w-3 h-3 bg-gray-400 rounded"></div>
                                  <span className="text-sm font-medium">Non-Billable Hours</span>
                                </div>
                                <div className="text-right">
                                  <p className="text-lg font-bold">{analyticsData.hoursBreakdown.nonBillable}h</p>
                                  <p className="text-sm text-muted-foreground">
                                    {formatPercentage(analyticsData.hoursBreakdown.nonBillable / analyticsData.hoursBreakdown.total)}
                                  </p>
                                </div>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-blue-500 h-2 rounded-full" 
                                  style={{ width: `${(analyticsData.hoursBreakdown.billable / analyticsData.hoursBreakdown.total) * 100}%` }}
                                ></div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Top Clients */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Top Clients by Revenue</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              {analyticsData.topClients.map((clientData, index) => (
                                <div key={clientData.client.id} className="flex items-center justify-between p-3 border rounded-lg">
                                  <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 bg-legal-purple text-white rounded-full flex items-center justify-center text-sm font-bold">
                                      {index + 1}
                                    </div>
                                    <div>
                                      <p className="font-medium">{clientData.client.name}</p>
                                      <p className="text-sm text-muted-foreground">{clientData.client.industry}</p>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <p className="font-bold">{formatCurrency(clientData.revenue)}</p>
                                    <p className="text-sm text-muted-foreground">
                                      {clientData.contracts} contracts • Risk: {clientData.averageRisk.toFixed(1)}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>

                        {/* Contract Type Breakdown */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Contract Type Analysis</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              {analyticsData.contractTypeBreakdown.map((type, index) => (
                                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                                  <div>
                                    <p className="font-medium">{type.type}</p>
                                    <p className="text-sm text-muted-foreground">
                                      {type.count} contracts • Avg Risk: {type.averageRisk.toFixed(1)}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <p className="font-bold">{formatCurrency(type.revenue)}</p>
                                    <p className="text-sm text-muted-foreground">
                                      {formatCurrency(type.revenue / type.count)} avg
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}

                    {!showAnalytics && (
                      <div className="space-y-4">
                        {/* Risk Trends Chart Placeholder */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                              <TrendingUp className="h-5 w-5" />
                              Risk Level Trends Over Time
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {analyticsData.riskTrends.map((trend, index) => (
                                  <div key={index} className="text-center p-3 border rounded-lg">
                                    <p className="text-sm text-muted-foreground">{trend.label}</p>
                                    <p className="text-2xl font-bold text-amber-600">{trend.value}</p>
                                    <p className="text-xs text-muted-foreground">Risk Score</p>
                                  </div>
                                ))}
                              </div>
                              <div className="text-center text-sm text-muted-foreground">
                                Risk scores are trending downward, indicating improved contract quality over time.
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Profitability Trends */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                              <DollarSign className="h-5 w-5" />
                              Profitability Trends
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {analyticsData.profitabilityTrends.map((trend, index) => (
                                  <div key={index} className="text-center p-3 border rounded-lg">
                                    <p className="text-sm text-muted-foreground">{trend.label}</p>
                                    <p className="text-2xl font-bold text-green-600">{formatPercentage(trend.value)}</p>
                                    <p className="text-xs text-muted-foreground">Profit Margin</p>
                                  </div>
                                ))}
                              </div>
                              <div className="text-center text-sm text-muted-foreground">
                                Profit margins are improving, showing better operational efficiency.
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Automated Contract Generation */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Automated Contract Generation
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Generate standard contracts using templates with pre-filled fields from CRM data
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Button
                        variant={showContractGeneration ? "default" : "outline"}
                        size="sm"
                        onClick={() => setShowContractGeneration(!showContractGeneration)}
                      >
                        <ContractIcon className="h-4 w-4 mr-2" />
                        Generate Contract
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowContractGeneration(false)}
                      >
                        <Database className="h-4 w-4 mr-2" />
                        CRM Integration
                      </Button>
                    </div>

                    {showContractGeneration && (
                      <div className="space-y-6">
                        {!selectedTemplate ? (
                          // Template Selection
                          <div className="space-y-4">
                            <h4 className="font-medium">Select Contract Template</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                              {contractTemplates.map((template) => (
                                <div 
                                  key={template.id} 
                                  className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                                  onClick={() => selectTemplate(template)}
                                >
                                  <div className="flex items-start justify-between mb-2">
                                    <h5 className="font-medium">{template.name}</h5>
                                    {/* @ts-ignore */}
                                    <Badge variant="outline" className="text-xs">
                                      {template.category}
                                    </Badge>
                                  </div>
                                  <p className="text-sm text-muted-foreground mb-3">{template.description}</p>
                                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                                    <span>Used {template.usageCount} times</span>
                                    <span>{template.frameworks.join(', ')}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          // Contract Generation Form
                          <div className="space-y-6">
                            <div className="flex items-center justify-between">
                              <div>
                                <h4 className="font-medium">{selectedTemplate.name}</h4>
                                <p className="text-sm text-muted-foreground">{selectedTemplate.description}</p>
                              </div>
                              <Button variant="outline" size="sm" onClick={resetContractGeneration}>
                                <RefreshCw className="h-4 w-4 mr-1" />
                                Change Template
                              </Button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {selectedTemplate.fields.map((field) => (
                                <div key={field.id} className="space-y-2">
                                  <Label htmlFor={field.id} className="text-sm font-medium">
                                    {field.label}
                                    {field.required && <span className="text-red-500 ml-1">*</span>}
                                  </Label>
                                  
                                  {field.type === 'text' && (
                                    <Input
                                      id={field.id}
                                      placeholder={field.placeholder}
                                      value={contractFormData[field.id] as string || ''}
                                      onChange={(e) => updateFormData(field.id, e.target.value)}
                                      className="w-full"
                                    />
                                  )}
                                  
                                  {field.type === 'textarea' && (
                                    <Textarea
                                      id={field.id}
                                      placeholder={field.placeholder}
                                      value={contractFormData[field.id] as string || ''}
                                      onChange={(e) => updateFormData(field.id, e.target.value)}
                                      className="w-full min-h-[80px]"
                                    />
                                  )}
                                  
                                  {field.type === 'date' && (
                                    <Input
                                      id={field.id}
                                      type="date"
                                      value={contractFormData[field.id] as string || ''}
                                      onChange={(e) => updateFormData(field.id, e.target.value)}
                                      className="w-full"
                                    />
                                  )}
                                  
                                  {field.type === 'number' && (
                                    <Input
                                      id={field.id}
                                      type="number"
                                      placeholder={field.placeholder}
                                      value={contractFormData[field.id] as number || ''}
                                      onChange={(e) => updateFormData(field.id, parseFloat(e.target.value) || 0)}
                                      className="w-full"
                                    />
                                  )}
                                  
                                  {field.type === 'select' && (
                                    <select
                                      id={field.id}
                                      value={contractFormData[field.id] as string || ''}
                                      onChange={(e) => updateFormData(field.id, e.target.value)}
                                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                                    >
                                      <option value="">{field.placeholder}</option>
                                      {field.options?.map((option) => (
                                        <option key={option} value={option}>
                                          {option.charAt(0).toUpperCase() + option.slice(1)}
                                        </option>
                                      ))}
                                    </select>
                                  )}
                                  
                                  {field.type === 'boolean' && (
                                    <div className="flex items-center space-x-2">
                                      <input
                                        id={field.id}
                                        type="checkbox"
                                        checked={contractFormData[field.id] as boolean || false}
                                        onChange={(e) => updateFormData(field.id, e.target.checked)}
                                        className="rounded"
                                      />
                                      <Label htmlFor={field.id} className="text-sm">
                                        {field.label}
                                      </Label>
                                    </div>
                                  )}

                                  {/* CRM Data Suggestion */}
                                  {field.crmMapping && contractFormData[field.id] && (
                                    <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                                      💡 CRM Data: {field.crmMapping} field mapped
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>

                            <div className="flex gap-2">
                              <Button 
                                onClick={generateContract}
                                disabled={!selectedTemplate.fields.every(field => 
                                  !field.required || contractFormData[field.id]
                                )}
                                className="bg-legal-purple hover:bg-legal-purple/90"
                              >
                                <Zap className="h-4 w-4 mr-2" />
                                Generate Contract
                              </Button>
                              <Button variant="outline" onClick={resetContractGeneration}>
                                Cancel
                              </Button>
                            </div>
                          </div>
                        )}

                        {/* Generated Contract Preview */}
                        {generatedContract && (
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-lg flex items-center gap-2">
                                <Eye className="h-5 w-5" />
                                Generated Contract Preview
                              </CardTitle>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span>Risk Score: {generatedContract.riskScore?.toFixed(1)}</span>
                                <span>Compliance: {generatedContract.complianceScore?.toFixed(0)}%</span>
                                <span>Status: {generatedContract.status}</span>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-4">
                                <ScrollArea className="h-64 w-full border rounded-lg p-4">
                                  <pre className="text-sm font-mono whitespace-pre-wrap">
                                    {generatedContract.generatedContent}
                                  </pre>
                                </ScrollArea>
                                
                                <div className="flex gap-2">
                                  <Button onClick={downloadContract} variant="outline">
                                    <Download className="h-4 w-4 mr-2" />
                                    Download
                                  </Button>
                                  <Button onClick={saveContract} variant="outline">
                                    <Save className="h-4 w-4 mr-2" />
                                    Save to Library
                                  </Button>
                                  <Button 
                                    onClick={() => {
                                      setContractText(generatedContract.generatedContent);
                                      setDocumentName(`${selectedTemplate?.name} - ${new Date().toLocaleDateString()}`);
                                      toast.success("Contract loaded for analysis!");
                                    }}
                                    className="bg-legal-purple hover:bg-legal-purple/90"
                                  >
                                    <FileText className="h-4 w-4 mr-2" />
                                    Analyze Contract
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    )}

                    {!showContractGeneration && (
                      <div className="space-y-4">
                        {/* CRM Integration Overview */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                              <Database className="h-5 w-5" />
                              CRM Integration Status
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div className="text-center p-4 border rounded-lg">
                                <div className="text-2xl font-bold text-blue-600">{crmData.clients.length}</div>
                                <div className="text-sm text-muted-foreground">Active Clients</div>
                              </div>
                              <div className="text-center p-4 border rounded-lg">
                                <div className="text-2xl font-bold text-green-600">{crmData.pastDeals.length}</div>
                                <div className="text-sm text-muted-foreground">Past Deals</div>
                              </div>
                              <div className="text-center p-4 border rounded-lg">
                                <div className="text-2xl font-bold text-purple-600">{contractTemplates.length}</div>
                                <div className="text-sm text-muted-foreground">Templates</div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Recent CRM Activity */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-lg">Recent CRM Activity</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              {crmData.pastDeals.slice(0, 3).map((deal) => (
                                <div key={deal.id} className="flex items-center justify-between p-3 border rounded-lg">
                                  <div>
                                    <p className="font-medium">{deal.contractType}</p>
                                    <p className="text-sm text-muted-foreground">
                                      {crmData.clients.find(c => c.id === deal.clientId)?.name}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <p className="font-bold">{formatCurrency(deal.value)}</p>
                                    <p className="text-sm text-muted-foreground">
                                      {new Date(deal.closedDate).toLocaleDateString()}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <div className="flex justify-between">
                <Button variant="outline" onClick={resetForm}>
                  Clear
                </Button>
                <Button 
                  onClick={handleAnalysis} 
                  disabled={isAnalyzing || !contractText.trim()}
                  className="bg-legal-purple hover:bg-legal-purple/90"
                >
                  {isAnalyzing ? "Analyzing..." : "Analyze Contract"}
                </Button>
              </div>
            </div>
          ) : (
            // Analysis Results
            <ScrollArea className="flex-1 overflow-hidden">
              <div className="space-y-6 p-1">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">Analysis Results</h3>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={exportAnalysis}>
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button variant="outline" size="sm" onClick={resetForm}>
                      New Analysis
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className={`${getRiskColor(analysis.overall_risk_level)} border`}>
                  <CardContent className="p-4 text-center">
                    <div className="flex items-center justify-center mb-2">
                      {getRiskIcon(analysis.overall_risk_level)}
                    </div>
                    <div className="text-2xl font-bold">
                      {analysis.overall_risk_level.toUpperCase()}
                    </div>
                    <div className="text-sm">Overall Risk</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {analysis.summary.red_clauses}
                    </div>
                    <div className="text-sm text-muted-foreground">High Risk</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-amber-600">
                      {analysis.summary.yellow_clauses}
                    </div>
                    <div className="text-sm text-muted-foreground">Medium Risk</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {analysis.summary.green_clauses}
                    </div>
                    <div className="text-sm text-muted-foreground">Low Risk</div>
                  </CardContent>
                </Card>
                </div>

                {/* Executive Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Executive Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <pre className="whitespace-pre-wrap text-sm font-mono leading-relaxed">
                        {executiveSummary}
                      </pre>
                    </div>
                  </CardContent>
                </Card>

                {/* Smart Suggestions */}
                {smartSuggestions.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Lightbulb className="h-5 w-5 text-blue-600" />
                        AI-Powered Smart Suggestions
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Intelligent alternatives for risky clauses based on your clause library and best practices
                      </p>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {smartSuggestions.map((suggestion, index) => (
                          <div key={suggestion.id} className="p-4 border rounded-lg bg-gradient-to-r from-blue-50 to-indigo-50">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <Lightbulb className="h-5 w-5 text-blue-600" />
                                <h4 className="font-semibold">Suggestion #{index + 1}</h4>
                                {/* @ts-ignore */}
                                <Badge variant="outline" className="bg-green-100 text-green-800">
                                  {suggestion.riskReduction}% risk reduction
                                </Badge>
                                {/* @ts-ignore */}
                                <Badge variant="outline" className="bg-blue-100 text-blue-800">
                                  {suggestion.confidence}% confidence
                                </Badge>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => copyClauseToClipboard(suggestion.suggestedClause)}
                                >
                                  <Copy className="h-4 w-4 mr-1" />
                                  Copy
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setContractText(prev => prev + '\n\n' + suggestion.suggestedClause);
                                    toast.success("Suggestion added to contract text!");
                                  }}
                                >
                                  <Plus className="h-4 w-4 mr-1" />
                                  Add to Contract
                                </Button>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                              <div>
                                <h5 className="font-medium text-red-600 mb-2 flex items-center gap-1">
                                  <AlertTriangle className="h-4 w-4" />
                                  Original Clause:
                                </h5>
                                <div className="bg-white p-3 rounded border text-sm font-mono max-h-32 overflow-y-auto">
                                  {suggestion.originalClause}
                                </div>
                              </div>
                              
                              <div>
                                <h5 className="font-medium text-green-600 mb-2 flex items-center gap-1">
                                  <CheckCircle className="h-4 w-4" />
                                  Suggested Improvement:
                                </h5>
                                <div className="bg-green-50 p-3 rounded border text-sm font-mono max-h-32 overflow-y-auto">
                                  {suggestion.suggestedClause}
                                </div>
                              </div>
                            </div>
                            
                            <div className="mt-3 p-3 bg-white rounded border">
                              <p className="text-sm text-muted-foreground mb-2">
                                <strong>Explanation:</strong> {suggestion.explanation}
                              </p>
                              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                <span>Frameworks: {suggestion.frameworks.join(', ')}</span>
                                {suggestion.templateId && (
                                  <span>Based on: {clauseLibrary.templates.find(t => t.id === suggestion.templateId)?.title}</span>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Detailed Analysis */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Detailed Clause Analysis</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Review each clause for potential risks and recommendations
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {analysis.clauses
                        .filter(clause => clause.risk_level !== 'green')
                        .map((clause, index) => (
                        <div key={index} className="space-y-3 p-4 border rounded-lg bg-white">
                          <div className="flex items-center justify-between">
                            {/* @ts-ignore */}
                            <Badge className={`${getRiskColor(clause.risk_level)} text-sm`}>
                              {getRiskIcon(clause.risk_level)}
                              <span className="ml-1">
                                {clause.clause_type.replace('_', ' ').toUpperCase()}
                              </span>
                            </Badge>
                            <div className="text-right">
                              <span className="text-sm text-muted-foreground">
                                Risk Score: {clause.risk_score.toFixed(2)}
                              </span>
                              <div className="text-xs text-muted-foreground">
                                Confidence: {(clause.confidence * 100).toFixed(0)}%
                              </div>
                            </div>
                          </div>
                          
                          <div className="bg-gray-50 p-3 rounded text-sm font-mono">
                            "{clause.text.length > 200 ? clause.text.substring(0, 200) + '...' : clause.text}"
                          </div>
                          
                          {clause.issues.length > 0 && (
                            <div className="space-y-2">
                              <h5 className="font-medium text-sm text-red-600 flex items-center gap-1">
                                <AlertTriangle className="h-4 w-4" />
                                Issues Found:
                              </h5>
                              <ul className="text-sm space-y-1 ml-4">
                                {clause.issues.map((issue, i) => (
                                  <li key={i} className="text-muted-foreground flex items-start gap-2">
                                    <span className="text-red-500 mt-1">•</span>
                                    <span>{issue}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {clause.suggestions.length > 0 && (
                            <div className="space-y-2">
                              <h5 className="font-medium text-sm text-green-600 flex items-center gap-1">
                                <CheckCircle className="h-4 w-4" />
                                Recommendations:
                              </h5>
                              <ul className="text-sm space-y-1 ml-4">
                                {clause.suggestions.map((suggestion, i) => (
                                  <li key={i} className="text-muted-foreground flex items-start gap-2">
                                    <span className="text-green-500 mt-1">•</span>
                                    <span>{suggestion}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {index < analysis.clauses.filter(c => c.risk_level !== 'green').length - 1 && (
                            <Separator className="my-4" />
                          )}
                        </div>
                      ))}
                      
                      {analysis.clauses.filter(c => c.risk_level !== 'green').length === 0 && (
                        <div className="text-center py-8 text-muted-foreground">
                          <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
                          <p className="text-lg font-medium">No High or Medium Risk Clauses Found</p>
                          <p className="text-sm">This contract appears to be in good shape!</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Compliance Frameworks Analysis */}
                {analysis.compliance_frameworks && analysis.compliance_frameworks.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Globe className="h-5 w-5" />
                        Compliance Framework Analysis
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Detailed compliance assessment across multiple regulatory frameworks
                      </p>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {analysis.compliance_frameworks.map((framework, index) => (
                          <div key={index} className="p-4 border rounded-lg bg-gray-50">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <span className="text-2xl">
                                  {complianceFrameworks.find(f => f.name === framework.framework)?.icon || '📋'}
                                </span>
                                <div>
                                  <h4 className="font-semibold">{framework.framework}</h4>
                                  <p className="text-sm text-muted-foreground">
                                    Compliance Score: {framework.compliance_score.toFixed(1)}/100
                                  </p>
                                </div>
                              </div>
                              {/* @ts-ignore */}
                              <Badge 
                                className={
                                  framework.compliance_score >= 80 
                                    ? "bg-green-100 text-green-800" 
                                    : framework.compliance_score >= 60 
                                    ? "bg-yellow-100 text-yellow-800"
                                    : "bg-red-100 text-red-800"
                                }
                              >
                                {framework.compliance_score >= 80 ? "Compliant" : 
                                 framework.compliance_score >= 60 ? "Partial" : "Non-Compliant"}
                              </Badge>
                            </div>
                            
                            {framework.violations.length > 0 && (
                              <div className="mb-3">
                                <h5 className="font-medium text-red-600 mb-2 flex items-center gap-1">
                                  <AlertTriangle className="h-4 w-4" />
                                  Compliance Violations:
                                </h5>
                                <ul className="space-y-1">
                                  {framework.violations.map((violation, i) => (
                                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                                      <span className="text-red-500 mt-1">•</span>
                                      <span>{violation}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                            
                            {framework.recommendations.length > 0 && (
                              <div>
                                <h5 className="font-medium text-green-600 mb-2 flex items-center gap-1">
                                  <CheckCircle className="h-4 w-4" />
                                  Framework Recommendations:
                                </h5>
                                <ul className="space-y-1">
                                  {framework.recommendations.map((rec, i) => (
                                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                                      <span className="text-green-500 mt-1">•</span>
                                      <span>{rec}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Risk Scoring by Framework */}
                {analysis.risk_scoring && analysis.risk_scoring.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Building className="h-5 w-5" />
                        Risk Scoring by Framework
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Risk assessment aligned with specific compliance frameworks
                      </p>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {analysis.risk_scoring.map((risk, index) => (
                          <div key={index} className={`p-4 border rounded-lg ${getRiskColor(risk.risk_level)}`}>
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-semibold">{risk.framework}</h4>
                              {/* @ts-ignore */}
                              <Badge className={getRiskColor(risk.risk_level)}>
                                {getRiskIcon(risk.risk_level)}
                                <span className="ml-1">{risk.risk_level.toUpperCase()}</span>
                              </Badge>
                            </div>
                            <div className="text-2xl font-bold mb-2">{risk.score.toFixed(1)}</div>
                            <p className="text-sm text-muted-foreground">{risk.explanation}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Contract Analytics Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      Contract Analytics Summary
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Key metrics and insights for this contract review
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center p-4 border rounded-lg">
                        <div className="text-2xl font-bold text-amber-600 mb-1">
                          {analysis.overall_risk_score.toFixed(1)}
                        </div>
                        <div className="text-sm text-muted-foreground">Overall Risk Score</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {analysis.overall_risk_level.toUpperCase()} Risk Level
                        </div>
                      </div>
                      
                      <div className="text-center p-4 border rounded-lg">
                        <div className="text-2xl font-bold text-blue-600 mb-1">
                          {analysis.summary.total_clauses}
                        </div>
                        <div className="text-sm text-muted-foreground">Total Clauses</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {analysis.summary.red_clauses} high risk • {analysis.summary.yellow_clauses} medium risk
                        </div>
                      </div>
                      
                      <div className="text-center p-4 border rounded-lg">
                        <div className="text-2xl font-bold text-green-600 mb-1">
                          {analysis.summary.compliance_violations}
                        </div>
                        <div className="text-sm text-muted-foreground">Compliance Violations</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {analysis.summary.applicable_frameworks.length} frameworks checked
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Compliance and Recommendations */}
                {(analysis.compliance_flags.length > 0 || analysis.recommendations.length > 0) && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {analysis.compliance_flags.length > 0 && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg text-amber-600">General Compliance Flags</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2">
                            {analysis.compliance_flags.map((flag, i) => (
                              <li key={i} className="flex items-start gap-2 text-sm">
                                <span className="text-amber-500 mt-1">⚠️</span>
                                <span>{flag}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}

                    {analysis.recommendations.length > 0 && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg text-blue-600">General Recommendations</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2">
                            {analysis.recommendations.map((rec, i) => (
                              <li key={i} className="flex items-start gap-2 text-sm">
                                <span className="text-blue-500 mt-1">💡</span>
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}